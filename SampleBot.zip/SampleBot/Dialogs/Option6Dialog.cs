﻿using Microsoft.Bot.Builder;
using Microsoft.Bot.Builder.Dialogs;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace EchoBot.Dialogs
{
    public class Option6Dialog : WaterfallDialog
    {
        public Option6Dialog(string dialogId, IEnumerable<WaterfallStep> steps = null)
            : base(dialogId, steps)
        {
            AddStep(async (stepContext, cancellationToken) =>
            {
                await stepContext.Context.SendActivityAsync(MessageFactory.Text($"Selected option 6"));
                return await stepContext.EndDialogAsync();
            });
        }
        public static new string Id => "Option6Dialog";

        public static Option6Dialog Instance { get; } = new Option6Dialog(Id);
    }
}
