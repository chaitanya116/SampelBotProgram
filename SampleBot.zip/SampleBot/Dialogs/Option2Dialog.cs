﻿using Microsoft.Bot.Builder;
using Microsoft.Bot.Builder.Dialogs;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace EchoBot.Dialogs
{
    public class Option2Dialog : WaterfallDialog
    {
        public Option2Dialog(string dialogId, IEnumerable<WaterfallStep> steps = null)
            : base(dialogId, steps)
        {
            AddStep(async (stepContext, cancellationToken) =>
            {
                await stepContext.Context.SendActivityAsync(MessageFactory.Text($"Selected option 2"));
                return await stepContext.EndDialogAsync();
            });
          

        }
        public static new string Id => "Option2Dialog";

        public static Option2Dialog Instance { get; } = new Option2Dialog(Id);
    }
}
